drop table users;
drop table board;

create table users(
	id 			varchar2(28) 	primary key,
	password 	varchar2(20)		not null,
	name 		varchar2(30)	not null,
	grade 		number(10)		default 1
)

create table board(
	seq			number(5) 		primary key,
	title		varchar2(200)	not null,
	nickname	varchar2(30)	not null,
	content		varchar2(2000)	not null,
	regdate		date 			default sysdate,
	cnt			number(5)		default 0,
	userid		varchar2(8),
	family 		number(5),
	parent 		number(5),
	depth 		number(5),
	indent 		number(5),
	constraint board_userid_fk foreign key(userid) references users(id)
)

insert into users values('gurum', 'gurum123', '채규태', 2);
insert into users values('abc', 'abc123', '홍길동', 2);
insert into users values('guest', 'guest123', '임꺽정', 2);
insert into users values('psw', '123', '된다된다', 3);
insert into users values('erika', '123', 'erika', 3);

insert into board(seq, title, nickname, content, regdate, userid, family, parent, depth, indent) 
values(1, '첫 번째 등록길', '야구신동', '첫 번째 등록글입니다.', '2012-02-05', 'gurum', 1, 0, 0, 0);
insert into board(seq, title, nickname, content, regdate, userid, family, parent, depth, indent) 
values(2, '두 번째 등록길', '야구신동', '두 번째 등록글입니다.', '2012-03-15', 'gurum', 2, 0, 0, 0);
insert into board(seq, title, nickname, content, regdate, userid, family, parent, depth, indent) 
values(3, '세 번째 등록길', '야구신동', '세 번째 등록글입니다.', '2012-03-03', 'gurum', 3, 0, 0, 0);
insert into board(seq, title, nickname, content, regdate, userid, family, parent, depth, indent) 
values(4, '네 번째 등록길', '야구신동', '네 번째 등록글입니다.', '2012-05-17', 'gurum', 4, 0, 0, 0);
insert into board(seq, title, nickname, content, regdate, userid, family, parent, depth, indent) 
values(5, '첫 번째 등록길', '나그네', '첫 번째 등록글입니다.', '2012-05-19', 'guest',	5, 0, 0, 0);
insert into board(seq, title, nickname, content, regdate, userid, family, parent, depth, indent) 
values(6, '두 번째 등록길', '나그네', '두 번째 등록글입니다.', '2012-12-25', 'guest', 6, 0, 0, 0);

insert into board(seq, title, nickname, content, regdate, userid, family, parent, depth, indent) 
values(7, '첫 번째 글', '된다된다', '첫 번째 등록글입니다.', '2015-05-10', 'psw', 7, 0, 0, 0);
insert into board(seq, title, nickname, content, regdate, userid, family, parent, depth, indent) 
values(8, '두 번째 글', '된다된다', '두 번째 등록글입니다.', '2015-05-10', 'psw', 8, 0, 0, 0);
insert into board(seq, title, nickname, content, regdate, userid, family, parent, depth, indent) 
values(9, '세 번째 글', '된다된다', '세 번째 등록글입니다.', '2015-05-10', 'psw', 9, 0, 0, 0);
insert into board(seq, title, nickname, content, regdate, userid, family, parent, depth, indent) 
values(10, '55기 하계수련대회', '된다된다', '삼성SDS 신입사원 다 모여라', '2015-05-11', 'psw', 10, 0, 0, 0);
insert into board(seq, title, nickname, content, regdate, userid, family, parent, depth, indent) 
values(11, '알고리즘 시험 안내', 'erika', '정올 홈페이지를 참고하세요.', '2015-05-16', 'erika', 11, 0, 0, 0);
insert into board(seq, title, nickname, content, regdate, userid, family, parent, depth, indent) 
values(12, '신입사원 전력화', 'erika', '또 하나의 혁명', '2015-05-14', 'erika', 12, 0, 0, 0);

select * from users;
select * from board;

