package com.samsung.view.board;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;

public class DeleteBoard extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Boolean deleteBoard;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int seq = Integer.parseInt(request.getParameter("seq"));
		
		BoardVO vo = new BoardVO();
		vo.setSeq(seq);
		BoardDAO dao = new BoardDAO();
		deleteBoard = dao.deleteBoard(vo);
		
		if(deleteBoard){
			response.sendRedirect("getBoardList");
		}else{
			BoardVO board = dao.getBoard(vo);
			request.setAttribute("board", board);
			request.setAttribute("msg", "댓글이 있는 게시글은 삭제할 수 없습니다!");
			
			RequestDispatcher dis = request.getRequestDispatcher("getBoard.jsp");
			dis.forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		doGet(request, response);
	}

}
