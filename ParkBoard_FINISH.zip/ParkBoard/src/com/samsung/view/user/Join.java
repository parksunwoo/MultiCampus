package com.samsung.view.user;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.biz.user.impl.UserDAO;
import com.samsung.biz.user.vo.UserVO;

public class Join extends HttpServlet {
	private static final long serialVersionUID = 1L;

	UserDAO uDao;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			uDao = new UserDAO();
			HttpSession s = request.getSession();
			String id = request.getParameter("id");
			String password = request.getParameter("password");
			String name = request.getParameter("name");

			UserVO vo = new UserVO(id, password, name);

			System.out.println(vo);

			int userInsert = uDao.userInsert(vo);

			System.out.println(userInsert);

			if (userInsert == 1) {
				s.setAttribute("id", vo.getId());
				s.setAttribute("name", vo.getName());
				response.sendRedirect("getBoardList");
			} else {
				response.sendRedirect("userInsert.jsp");
			}

			/*
			 * ArrayList<UserVO> puList = uDao.usersList();
			 * request.setAttribute("puList", puList);
			 * request.getRequestDispatcher
			 * ("jsp/pUserList.jsp").forward(request, response);
			 */

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

}
