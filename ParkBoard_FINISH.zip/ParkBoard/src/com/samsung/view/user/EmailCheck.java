package com.samsung.view.user;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.biz.user.impl.UserDAO;
import com.samsung.biz.user.vo.UserVO;

public class EmailCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;

	UserDAO uDao;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		boolean isDupl = false;
		try {
			uDao = new UserDAO();

			HttpSession s = request.getSession();
			String id = request.getParameter("id");
			if (id != null) {

				UserVO userVO = uDao.searchEmail(id);
				request.setAttribute("id", id);

				if (userVO != null) {
					isDupl = true;
					request.setAttribute("isDupl", isDupl);
					request.getRequestDispatcher("duplicate.jsp").forward(
							request, response);
					return;
				} else {
					request.setAttribute("isDupl", isDupl);
					request.getRequestDispatcher("duplicate.jsp").forward(
							request, response);
					return;
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

}
