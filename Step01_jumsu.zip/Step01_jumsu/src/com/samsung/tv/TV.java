package com.samsung.tv;

public interface TV {
	public void powerOn();
	public void powerOff();
	public void volumnUp();
	public void volumnDown();
}
