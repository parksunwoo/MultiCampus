package com.samsung.tv;

public class LGTV implements TV {
	public void powerOn() {
		System.out.println("LGTV => 전원 켜기");
	}
	public void powerOff() {
		System.out.println("LGTV => 전원 끄기");
	}
	public void volumnUp() {
		System.out.println("LGTV => 소리 올리기");
	}
	public void volumnDown() {
		System.out.println("LGTV => 소리 내리기");
	}
}
