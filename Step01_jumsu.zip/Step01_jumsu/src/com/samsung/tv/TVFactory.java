package com.samsung.tv;

public class TVFactory {
	//어떤 객체를 사용할 지를 결정
	public Object getBean(String tv){
		if(tv.equals("Samsung")){
			return new SamsungTV(); 
		}else if(tv.equals("LG")){
			return new LGTV();
		}
		return null;
	}
}
