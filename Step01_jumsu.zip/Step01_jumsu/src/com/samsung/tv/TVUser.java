package com.samsung.tv;


public class TVUser {
	public static void main(String[] args) {
		TVFactory factory = new TVFactory();
		TV tv = (TV) factory.getBean(args[0]);
//		SamsungTV tv = new SamsungTV();
//		LGTV tv = new LGTV();
		tv.powerOn();
		tv.volumnUp();
		tv.volumnDown();
		tv.powerOff();
	}
}
