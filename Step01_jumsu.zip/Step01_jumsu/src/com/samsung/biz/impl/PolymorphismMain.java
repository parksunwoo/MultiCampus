package com.samsung.biz.impl;

public class PolymorphismMain {
	public static void main(String[] args) {
//		Jumsu jumsu = new Three("홍길동", 90, 80, 100);
		
		//사용할 객체는 Factory로 부터 주입받아(Dependency injection) 사용한다. -> 의존성 주입
		JumsuFactory factory = new JumsuFactory();
		Jumsu jumsu = factory.getJumsu();
		jumsu.display();
		
//		Jumsu jumsu1 = (Jumsu) factory.getBean();
		
	}
}
