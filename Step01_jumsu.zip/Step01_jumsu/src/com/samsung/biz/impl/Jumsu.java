package com.samsung.biz.impl;

public interface Jumsu {
	public void onTotal();
	public void onAvg();
	public void display();
}
