package com.samsung.biz.impl;

public class JumsuFactory {
	//말 그대로 클래스 공장. 어떤 클래스를 사용할 지 정해서 그 클래스를 생성해서 리턴하는 목적으로 만드는 클래스
	
	//Object Type은 모든 객체의 부모 타입
	//대신, 사용할 때 down casting을 해야함
	public Jumsu getJumsu(){
//		return new Three("홍길동", 90, 80, 100);
		return new Two("홍길동", 90, 80);
	}
/*	public Object getBean(){
		return new Three("홍길동", 90, 80, 100);
		return jumsu;
	}  ->  Spring*/
}
