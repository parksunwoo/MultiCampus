package com.samsung.biz.impl;

public class Main {
	public static void main(String[] args) {
		//단지 부모 역할만 할 껍데기 클래스
		Jumsu hong = new Two("홍길동", 100, 95);
		Jumsu im = new Three("임꺽정", 100, 95, 45);
		Jumsu jimea = new Four("일지매", 75, 95, 45, 95);
		//다형성을 위해 자식들이 호출되어 사용될 껍데기 메소드만 정의한다.
		
		//1등 구하는 것은 전과 동일
		
	}
}
