package com.samsung.biz.inher;

import java.util.ArrayList;

public class JumsuMain {
	public static void main(String[] args) {
		/*JumsuTwo hong = new JumsuTwo("홍길동", 100, 95);
		hong.display();
		
		JumsuThree im = new JumsuThree("임꺽정", 100, 95, 45);
		im.display();
		
		JumsuFour jimea = new JumsuFour("일지매", 75, 95, 45, 95);
		jimea.display();*/

/*		JumsuTwo im1 = im;
		JumsuTwo jimea1 = jimea;
*/		
		//내가 만든 클래스도 변수의 타입
		//상속관계에서는 부모는 자식 보다 큰 타입이다.
		//따라서 다음과 같은 정의가 가능
		//JumsuTwo > JumsuThree > JumsuFour

		/*JumsuTwo hong = new JumsuTwo("홍길동", 100, 95);
		JumsuTwo im = new JumsuThree("임꺽정", 100, 95, 45);
		JumsuTwo jimea = new JumsuFour("일지매", 75, 95, 45, 95);*/
		
		JumsuTwo test = new JumsuThree("임꺽정", 100, 95, 45);
		test.onTwo();
		
		int top = 0;
		JumsuTwo topPerson = null;
//		JumsuTwo[] jumsu = {hong, im, jimea};
		
		ArrayList<JumsuTwo> jumsu = new ArrayList<>();
		jumsu.add(new JumsuTwo("홍길동", 100, 95));
		jumsu.add(new JumsuThree("임꺽정", 100, 95, 45));
		jumsu.add(new JumsuFour("일지매", 75, 95, 45, 95));
		
		for (JumsuTwo su : jumsu) {
			su.display();
			if(su.vo.getAvg() > top){
				top = su.vo.getAvg();
				topPerson = su;
			}
		}
		/*for (int i = 0; i < jumsu.size(); i++) {
			JumsuTwo su = jumsu.get(i);
			su.display();
			if(su.vo.getAvg() > top){
				top = su.vo.getAvg();
				topPerson = su;
			}
		}*/
		System.out.println(top);
		System.out.println(topPerson.vo.getName());
		
		/*int i = 10;
		long lo = i;
		int i1 = (int)lo;
		Integer it = new Integer(10);
		it.toBinaryString(i);
		Double d = new Double(10.5);
		Double d1 = new Double(it);*/
		
		
		//클래스는 모든 자식보다 부모가 큰 타입이다!!!
		
		
		//메소드를 자신에 맞게끔 잘 정의해서 사용하자.
		
		/*JumsuVO vo1 = new JumsuVO();
		vo1.setName("홍길동");
		vo1.setKor(100);
		vo1.setEng(75);
		System.out.println(vo1);

		JumsuVO vo2 = new JumsuVO();
		vo2.setName("홍길동");
		vo2.setKor(100);
		vo2.setEng(75);
		System.out.println(vo2);
		
		System.out.println("vo1 => " + vo1.hashCode());
		System.out.println("vo2 => " + vo2.hashCode());
		if(vo1.equals(vo2)){
			System.out.println("같은 객체");
		}else{
			System.out.println("다른 객체");
		}*/
	}
}
