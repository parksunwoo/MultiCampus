package com.samsung.biz.nalcoding;

public class A02_JumsuArray {
	public static void main(String[] args) {
		//변수가 A01보다 더 줄어들었다. -> 코드를 읽고 쓰기 쉽다
		String[] name = {"홍길동", "임꺽정", "일지매" };
		int[] hong = {90, 75, 85, 0, 0};
		int[] im = {100, 95, 85, 0, 0};
		int[] jimea = {100, 95, 100, 0, 0};

		//hong
		for (int i = 0; i < hong.length; i++) {
			hong[3] = hong[0] + hong[1] + hong[2];
		}
		hong[4] = hong[3] / 3;
		
		//im
		for (int i = 0; i < im.length; i++) {
			im[3] = im[0] + im[1] + im[2];
		}
		im[4] = im[3] / 3;

		//jimea
		for (int i = 0; i < jimea.length; i++) {
			jimea[3] = jimea[0] + jimea[1] + jimea[2];
		}
		jimea[4] = jimea[3] / 3;
		
		//출력
		System.out.println(name[0] + "님의 총점은 " + hong[3] + "이고 평균은 " + hong[4] + "입니다.");
		System.out.println(name[1] + "님의 총점은 " + im[3] + "이고 평균은 " + im[4] + "입니다.");
		System.out.println(name[2] + "님의 총점은 " + jimea[3] + "이고 평균은 " + jimea[4] + "입니다.");
		
	}
}
