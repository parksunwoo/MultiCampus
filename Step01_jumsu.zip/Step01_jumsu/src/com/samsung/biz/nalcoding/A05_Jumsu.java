package com.samsung.biz.nalcoding;

//내가 만든 클래스도 변수명(변수타입)이다.
//이렇게 만들면 다양한 타입의 변수를 하나의 이름으로 관리할 수 있다.
public class A05_Jumsu {
	private String name;
	private int kor;
	private int eng;
	private int math;
	private int total;
	private int avg;
	
	
	//초기화 메소드 - 매개변수를 갖는 메소드ㄱ
/*	void settings(String n, int k, int e, int m){
		name = n;
		kor = k;
		eng = e;
		math = m;
	}*/

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getKor() {
		return kor;
	}

	public void setKor(int kor) {
		this.kor = kor;
	}

	public int getEng() {
		return eng;
	}

	public void setEng(int eng) {
		this.eng = eng;
	}

	public int getMath() {
		return math;
	}

	public void setMath(int math) {
		this.math = math;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getAvg() {
		return avg;
	}

	public void setAvg(int avg) {
		this.avg = avg;
	}

	public A05_Jumsu() {
	}
	
	//인스턴스객체는 생성자메소드를 통해서 태어난다.
	//jvm은 생성자 메소드가 없으면 기본 생성자 메소드를 자동으로 만들어준다. 형태는 다음과 같다.
	//생성자 메소드를 프로그래머가 하나라도 만들면 기본 생성자 메소드를 jvm은 만들어 주지 않는다.
	//따라서 필요하면 꼭 프로그래머가 정의 해 주어야 한다.
	
	//생성자 오버로딩
	public A05_Jumsu(String name, int kor) {
		this.name = name;
		this.kor = kor;
	}
	
	//생성자 메소드명은 이름대신 this()를 사용한다.
	public A05_Jumsu(String name, int kor, int eng, int math) {
		this(name, kor);
		this.eng = eng;
		this.math = math;
	}
	//this 사용목적
	//1. 멤버변수와 매개변수를 구분해준다.
	//2. 자기의 생성자를 호출할 때 사용한다.
	
	//사용자가 해야 할 일을 묶어서 여기서 처리하자 => 메소드
	//클래스 안쪽의 참조하는 멤버변수, 멤버 메소드의 앞에는 this가 생략된 형태다
	void onTotal(){
		total = this.kor + eng + math;
	}
	//일반 메소드의 오버로딩
	void onAvg(){
		avg = total / 3;
	}
	//접근제어자를 쓰지 않으면 default값으로 같은 패키지 내에서만 사용 가능하다.
	void onAvg(int su){
		avg = total / su;
	}
	void display(){
		onTotal();
		onAvg();
		System.out.println(name + "님의 총점은 " + total + "이고 평균은 " + avg + "입니다.");
	}
	
}
