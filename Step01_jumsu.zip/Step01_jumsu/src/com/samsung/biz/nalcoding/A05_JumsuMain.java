package com.samsung.biz.nalcoding;

public class A05_JumsuMain {
	public static void main(String[] args) {
		
		A05_JumsuDAO hong = new A05_JumsuDAO("홍길동", 90, 80, 70);
		A05_JumsuDAO im = new A05_JumsuDAO("임꺽정", 100, 90, 80);
		A05_JumsuDAO jimea = new A05_JumsuDAO("일지매", 100, 95, 100);
	/*	A05_Jumsu hong = new A05_Jumsu("홍길동", 90, 80, 70);
		A05_Jumsu im = new A05_Jumsu("임꺽정", 100, 90, 80);
		A05_Jumsu jimea = new A05_Jumsu("일지매", 100, 95, 100);
		
		//메소드도 똑같이 호출한다. 단, 메소드는 ()가 붙는다.
//		hong.name = "홍길동";
//		hong.kor = 90;
//		hong.eng = 80;
//		hong.math = 70;
//		hong.total = hong.kor + hong.eng + hong.math;
//		hong.avg = hong.total / 3;
//		hong.settings("홍길동", 90, 80, 70);
//		hong.onTotal();
//		hong.onAvg();

//		im.name = "임꺽정";
//		im.kor = 100;
//		im.eng = 90;
//		im.math = 80;
//		im.total = im.kor + im.eng + im.math;
//		im.avg = im.total / 3;
//		im.settings("임꺽정", 100, 90, 80);
//		im.onTotal();
//		im.onAvg();
		
//		jimea.name = "일지매";
//		jimea.kor = 100;
//		jimea.eng = 95;
//		jimea.math = 100;
//		jimea.total = jimea.kor + jimea.eng + jimea.math;
//		jimea.avg = jimea.total / 3;
//		jimea.settings("일지매", 100, 95, 100);
//		jimea.onTotal();
//		jimea.onAvg();
		
//		jimea.math = 100; -> private으로 막음
		
		hong.display();
		im.display();
		jimea.display();
		
		A05_Jumsu nol = new A05_Jumsu();
		nol.setName("놀부");
		nol.setKor(95);
		nol.setEng(35);
		nol.setMath(74);
//		nol.setTotal(nol.getKor() + nol.getEng() + nol.getMath());
//		nol.setAvg(nol.getTotal() / 3);
		nol.display();*/
	}
}
