package com.samsung.biz.nalcoding;

import java.util.ArrayList;

public class A04_jumsuArrayList {
	public static void main(String[] args) {
		ArrayList<String> name = new ArrayList<>();
		name.add("홍길동");
		name.add("일지매");
		name.add("임꺽정");
		ArrayList<Integer> hong = new ArrayList<>();
		hong.add(90);
		hong.add(75);
		hong.add(85);
		ArrayList<Integer> im = new ArrayList<>();
		im.add(100);
		im.add(95);
		im.add(85);
		ArrayList<Integer> jimea = new ArrayList<>();
		jimea.add(100);
		jimea.add(95);
		jimea.add(100);
		
		ArrayList<ArrayList<Integer>> jumsu = new ArrayList<>();
		jumsu.add(hong);
		jumsu.add(im);
		jumsu.add(jimea);
		
		for (int i = 0; i < jumsu.size(); i++) {
			ArrayList<Integer> su = jumsu.get(i);
			int total = 0;
			for (int j = 0; j < su.size(); j++) {
				total = su.get(0)+su.get(1)+su.get(2);
			}
			su.add(total);
			su.add(total / 3);
			System.out.println(name.get(i) + "님의 총점은 " + su.get(3) + "이고 평균은 "+ su.get(4) + "입니다.");
		}
		
		//이름을 뽑아서 쓰려면 index를 알아야하기 때문에 불편!!! 그래서 객체가 생겨났다.
	}
}
