package com.samsung.view.user;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.samsung.biz.user.impl.UserDAO;
import com.samsung.biz.user.vo.UserInfo;


@Controller
public class UserController {
	@Autowired
	@Qualifier("userDAO")
	private UserDAO dao;
	// ȸ������
	@RequestMapping("join.do")
	public String join(HttpSession session, UserInfo vo, Model md) {
			int userInsert = 0;
			try {
				userInsert = dao.userInsert(vo);
			} catch (Exception e) {
				String msg = "ȸ�������� �Ϸ�����ʾҽ��ϴ�. �ٽ� �������ּ���";
				md.addAttribute("msg", msg);
				return "/sitepage.jsp?content=error.jsp";
			}
			
			if (userInsert == 1) {
				session.setAttribute("id", vo.getId());
				session.setAttribute("name", vo.getName());
				return "/sitepage.jsp";
			} else {
				String msg = "ȸ�������� �Ϸ�����ʾҽ��ϴ�. �ٽ� �������ּ���";
				md.addAttribute("msg", msg);
				return "/sitepage.jsp?content=error.jsp";
			}
	}
	// �α���
	@RequestMapping("login.do")
	public String login(HttpSession session, UserInfo vo, Model md) {
		UserInfo user = dao.login(vo);

		if (user != null) {
			session.setAttribute("name", user.getName());
			session.setAttribute("id", user.getId());
			session.setAttribute("user", user.getId());
			//md.addAttribute("content", "/calendar.jsp");
			return "/sitepage.jsp";
		} else {
			String msg = "�α��� ������ �ٽ� Ȯ�����ּ���";
			md.addAttribute("msg", msg);
			//md.addAttribute("content", "/error.jsp");
			return "/sitepage.jsp?content=error.jsp";
		}
	}
	// �α׾ƿ�
	@RequestMapping("logout.do")
	public String logout(HttpSession session, UserInfo vo ){
		session.invalidate();
		return "sitepage.jsp?content=index.jsp";
	}
	// ȸ������(������)
	@RequestMapping("deleteUser.do")
	public String deleteUser(HttpSession session, UserInfo vo ){
		dao.userDelete(vo);
		
		return "/sitepage.jsp";
	}
	// ȸ����Ϻҷ�����
	@RequestMapping("listUser.do")
	public String listUser(HttpSession session, UserInfo vo, Model md){
		String id = (String) session.getAttribute("id");
		if (id == null) {
			return "login.jsp";
		}
		ArrayList<UserInfo> userList = dao.userList();
		md.addAttribute("list", userList);
		md.addAttribute("content", "admin/admin_userList.jsp");
		return "/sitepage.jsp?content=admin/admin_userList.jsp";
	}
	
	
}