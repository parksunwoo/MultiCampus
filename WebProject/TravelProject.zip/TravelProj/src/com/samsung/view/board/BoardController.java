package com.samsung.view.board;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;
import com.samsung.biz.common.AdvancedPageUtility;

@Controller
public class BoardController {

	@Autowired
	@Qualifier("boardDAO")
	private BoardDAO dao;
	
	private Boolean deleteBoard;
	// �Խ��� ���۵��
	@RequestMapping("addBoard.do")
	public String addBoard(@RequestParam("today") String today,
			BoardVO vo, HttpSession session){
		
		String id = (String) session.getAttribute("id");
		if (id == null) {
			return "login.jsp";
		}
		
		dao.addBoard(vo, today);
		return "getBoardList.do";
	}
	// �Խ��� ��۴ޱ�
	@RequestMapping("addReply.do")
	public String addReply(@RequestParam("today") String today, BoardVO vo, HttpSession session){
		String id = (String) session.getAttribute("id");
		if (id == null) {
			return "login.jsp";
		}
		
		dao.addReply(vo, today);
		return "getBoardList.do";
	}
	// �Խ��� ����(����� �ִ� �Խ����� �����Ұ�)
	@RequestMapping("deleteBoard.do")
	public String deleteBoard (BoardVO vo, HttpSession session, Model md) {
		String id = (String) session.getAttribute("id");
		if (id == null) {
			return "login.jsp";
		}
		deleteBoard = dao.deleteBoard(vo);

		if (deleteBoard) {
			return "getBoardList.do";
		} else {
			BoardVO board = dao.getBoard(vo);
			md.addAttribute("board", board);
			md.addAttribute("msg", "����� �޸� ���� ������ �� �����ϴ�!");
			return "getBoard.jsp";
		}
	}
	// �Խ��� �󼼺���
	@RequestMapping("getBoard.do")
	public String getBoard(BoardVO vo, HttpSession session, Model md) {
		String id = (String) session.getAttribute("id");
		if (id == null) {
			return "login.jsp";
		}
		BoardVO board = dao.getBoard(vo);
		
		//request.setAttribute("board", board);
		md.addAttribute("board", board);
		return "/sitepage.jsp?content=getBoard.jsp";
	}
	// �Խø�� �ҷ����� (����¡�۾�)
	@RequestMapping("getBoardList.do")
	public String getBoardList(@RequestParam(value="pageNo", defaultValue="1") String cpage,
			BoardVO vo, HttpSession session, Model md) {
		String id = (String) session.getAttribute("id");
		if (id == null) {
			return "login.jsp";
		}

		String searchCondition = "";
		if (vo.getSearchCondition() == null) {
			vo.setSearchCondition("TITLE");
		}  

		String searchKeyword = "";
		if (vo.getSearchKeyword() == null) {
			vo.setSearchKeyword("");
		}
		// / ����¡ �۾� ����
		ArrayList<BoardVO> list = null;
		int page = 1;

		if (cpage != null) {
			page = Integer.parseInt(cpage);
		} 
		
		try {

			int interval = 10; // �� �������� ������ ��ǰ ����
			list = dao.getBoardList(vo, page, interval);
			int total = dao.getTotalRecord();
			total = total == 0 ? 1 : total;

			// PageUtility bar = new PageUtility(interval, total,page);
			AdvancedPageUtility bar = new AdvancedPageUtility(interval, total,
					page, "images/");
			md.addAttribute("pageLink", bar.getPageBar());
			md.addAttribute("list", list);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/sitepage.jsp?content=getBoardList.jsp";
		
	}
	// ��� �Է������� �ҷ�����
	@RequestMapping("replyBoard.do")
	public String replyBoard(BoardVO vo, HttpSession session, Model md) {
		String id = (String) session.getAttribute("id");
		if (id == null) {
			return "login.jsp";
		}
		
		BoardVO reBoard = dao.replyBoard(vo);
		md.addAttribute("reBoard", reBoard);
		return "/sitepage.jsp?content=reply_form.jsp";
	}
	// �Խñ� ����
	@RequestMapping("updateBoard.do")
	public String updateBoard(BoardVO vo, HttpSession session) {
		String id = (String) session.getAttribute("id");
		if (id == null) {
			return "login.jsp";
		}
		dao.updateBoard(vo);
		return "getBoardList.do";
	}
}
