package com.samsung.biz.common;


public class AdvancedPageUtility {
    int firstPageCount=0;
    int lastPageCount=0;

    int currentPageCount=0;			
	
    int pagePerCount = 3;				 
    int beforePage=0;						
    int nextPage=0;							

    int totalRowCount=0;				
    int totalPageCount=0;				
    int displayRowCount=0;			
    String imagePath;
    
	public AdvancedPageUtility(int displayRowCount, int totalRowCount,
			int currentPageCount, String imagePath) throws Exception {
		super();
		this.displayRowCount = displayRowCount;
		this.totalRowCount = totalRowCount;
		this.currentPageCount = currentPageCount;
		this.imagePath = imagePath;
		
		if (totalRowCount % displayRowCount == 0){
			this.totalPageCount = totalRowCount / displayRowCount;
		}else{
			this.totalPageCount = totalRowCount / displayRowCount + 1;
		}
	}
    public String getCurrentPageCount()
    {
        return String.valueOf(currentPageCount);
    }
    public String getPageBar()    {
    	
        StringBuffer sb=new StringBuffer();
        firstPageCount=((currentPageCount-1)/pagePerCount*pagePerCount)+1;
        lastPageCount=firstPageCount+pagePerCount - 1;
        
		if(firstPageCount  != 1){
			beforePage = firstPageCount - pagePerCount;
		}else{
			beforePage = 1;
		}

        if(lastPageCount < totalPageCount){
            nextPage=lastPageCount +1;        	
        }else{
        	lastPageCount = totalPageCount;
        	nextPage = totalPageCount;
        }
        
//        System.out.println("firstPageCount:"+firstPageCount);
//        System.out.println("lastPageCount:"+lastPageCount);
//        System.out.println("totalPageCount:"+totalPageCount);
//        System.out.println("beforePage:"+beforePage);
//        System.out.println("nextPage:"+nextPage);
       
        if(firstPageCount>pagePerCount){ 
            sb.append(" <a href='javascript:pagelist("+1+")'><img src=\""+imagePath+"btn_first.gif\" border='0'  hspace='3' align='absmiddle'></a>&nbsp;&nbsp;");
        }else{  
            sb.append("<img src=\""+imagePath+"btn_first.gif\" border='0'  align=absmiddle>&nbsp;&nbsp;");
        }

        if(firstPageCount > beforePage){
        	sb.append("<a href='javascript:pagelist("+ beforePage+")'><img src=\""+imagePath+"btn_prev.gif\" border='0' hspace='3' align=absmiddle></a>&nbsp;&nbsp;");
        }else{
        	sb.append("<img src=\""+imagePath+"btn_prev.gif\" border='0'   align=absmiddle>&nbsp;&nbsp;");
        }

        for (int i = firstPageCount; i <= lastPageCount; i++)
        {
                if (i == currentPageCount){
                    sb.append("<b>" + i + "</b>");
                }else{
                    sb.append("<a href='javascript:pagelist("+i+")'>" + i + "</a>");
                }
                
                if( i !=lastPageCount ){
                    sb.append("&nbsp;");
                }

        }

        if(lastPageCount < nextPage){
        	sb.append("&nbsp;&nbsp;<a href='javascript:pagelist("+ (nextPage)+ ")'><img src=\""+imagePath+"btn_next.gif\" border='0' hspace='3' align=absmiddle></a>");
        }else{
        	sb.append("&nbsp;&nbsp;<img src=\""+imagePath+"btn_next.gif\" border='0' hspace='3' align=absmiddle>");
        }
        
        if(lastPageCount< totalPageCount){
            sb.append("&nbsp;&nbsp;<a href='javascript:pagelist("+ (totalPageCount)+")'><img src=\""+imagePath+"btn_end.gif\" border='0' align=absmiddle></a>");
        }else{
            sb.append("&nbsp;&nbsp;<img src=\""+imagePath+"btn_end.gif\" border='0' align=absmiddle>");
        }
        
        return sb.toString();
    }
    public String getTotalPageCount() {       return String.valueOf(totalPageCount);
    }
}