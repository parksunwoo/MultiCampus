package com.samsung.biz.user.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.samsung.biz.user.vo.UserInfo;

@Repository("userDAO")
public class UserDAO {
	@Autowired
	@Qualifier("sqlSession")
	private SqlSession myBatis = null;
	 

	public UserInfo login(UserInfo vo) {
		UserInfo user = myBatis.selectOne("getUser", vo);
		return user;
	}

	public int userInsert(UserInfo vo) {
		int result = 0;
		result = myBatis.insert("addUser", vo);
		return result;
	}

	public int userDelete(UserInfo vo) {
		int result = 0;
		result = myBatis.delete("deleteUser", vo);
		return result;
	}

	public ArrayList<UserInfo> userList() {
		List<Object> uList = myBatis.selectList("userList");
		return (ArrayList)uList;
	}
}
