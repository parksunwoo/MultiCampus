package com.scsa.model.vo;

public class Schedule {

	private int schedulenum; 
	private String id;
	private String schedulestart;
	private String scheduleend;
	private String schedulenation;
	private String city;
	private String schedulesite;
	
	public int getSchedulenum() {
		return schedulenum;
	}
	public void setSchedulenum(int schedulenum) {
		this.schedulenum = schedulenum;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSchedulestart() {
		return schedulestart;
	}
	public void setSchedulestart(String schedulestart) {
		this.schedulestart = schedulestart;
	}
	public String getScheduleend() {
		return scheduleend;
	}
	public void setScheduleend(String scheduleend) {
		this.scheduleend = scheduleend;
	}
	public String getSchedulenation() {
		return schedulenation;
	}
	public void setSchedulenation(String schedulenation) {
		this.schedulenation = schedulenation;
	}
	public String getSchedulesite() {
		return schedulesite;
	}
	public void setSchedulesite(String schedulesite) {
		this.schedulesite = schedulesite;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Schedule(int schedulenum, String id, String schedulestart,
			String scheduleend, String schedulenation, String city,
			String schedulesite) {
		super();
		this.schedulenum = schedulenum;
		this.id = id;
		this.schedulestart = schedulestart;
		this.scheduleend = scheduleend;
		this.schedulenation = schedulenation;
		this.city = city;
		this.schedulesite = schedulesite;
	}
	public Schedule(String id, String schedulestart, String scheduleend,
			String schedulenation, String city, String schedulesite) {
		super();
		this.id = id;
		this.schedulestart = schedulestart;
		this.scheduleend = scheduleend;
		this.schedulenation = schedulenation;
		this.city = city;
		this.schedulesite = schedulesite;
	}
	
	public Schedule(String schedulenation, String city, String id) {
		super();
		this.schedulenation = schedulenation;
		this.city = city;
		this.id = id;
	}
	@Override
	public String toString() {
		return "Schedule [schedulenum=" + schedulenum + ", id=" + id
				+ ", schedulestart=" + schedulestart + ", scheduleend="
				+ scheduleend + ", schedulenation=" + schedulenation
				+ ", city=" + city + ", schedulesite="
				+ schedulesite + "]";
	}
	
}
