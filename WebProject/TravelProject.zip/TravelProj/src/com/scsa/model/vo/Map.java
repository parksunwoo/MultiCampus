package com.scsa.model.vo;

public class Map {
	
	private String city;
	private String infonation;
	private double latitude;
	private double longitude;
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getInfonation() {
		return infonation;
	}
	public void setInfonation(String infonation) {
		this.infonation = infonation;
	}
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	public Map(String city, String infonation, double latitude,
			double longitude) {
		super();
		this.city = city;
		this.infonation = infonation;
		this.latitude = latitude;
		this.longitude = longitude;
	}
	@Override
	public String toString() {
		return "Map [city=" + city + ", infonation=" + infonation
				+ ", latitude=" + latitude + ", longitude=" + longitude + "]";
	}
}
