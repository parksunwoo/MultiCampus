package com.scsa.model.vo;


public class Info {
	private int infonum;
	private String infonation;
	private String infoimage;
	private String infodesc;
	public Info() {
		super();
	}
	public int getInfonum() {
		return infonum;
	}
	public void setInfonum(int infonum) {
		this.infonum = infonum;
	}
	public String getInfonation() {
		return infonation;
	}
	public void setInfonation(String infonation) {
		this.infonation = infonation;
	}
	public String getInfoimage() {
		return infoimage;
	}
	public void setInfoimage(String infoimage) {
		this.infoimage = infoimage;
	}
	public String getInfodesc() {
		return infodesc;
	}
	public void setInfodesc(String infodesc) {
		this.infodesc = infodesc;
	}
	public Info(int infonum, String infonation, String infoimage,
			String infodesc) {
		super();
		this.infonum = infonum;
		this.infonation = infonation;
		this.infoimage = infoimage;
		this.infodesc = infodesc;
	}
	@Override
	public String toString() {
		return "Info [infonum=" + infonum + ", infonation=" + infonation
				+ ", infoimage=" + infoimage + ", infodesc=" + infodesc + "]";
	}
	
}
