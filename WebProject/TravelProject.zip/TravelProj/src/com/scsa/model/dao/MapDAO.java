package com.scsa.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.samsung.biz.common.JDBCUtils;
import com.scsa.model.vo.Map;
public class MapDAO {
	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	public void addMap(Map m) throws SQLException {
    	String query = "insert into map values(?,?,?,?)";
    	try {
    		con = JDBCUtils.getConnection();
    		ps = con.prepareStatement(query);
    		ps.setString(1, m.getCity());
    		ps.setString(2, m.getInfonation());
    		ps.setDouble(3, m.getLatitude());
    		ps.setDouble(4, m.getLongitude());
    		ps.executeUpdate();
    		
    	} finally {
    		JDBCUtils.close(con, ps);
    	}
    }
    
    public void deleteMap(String city) throws SQLException {
    	String sql = "delete from map where city=?";
		try {
			con = JDBCUtils.getConnection();
			ps = con.prepareStatement(sql);
			ps.setString(1, city);
			ps.executeUpdate();
		} finally {
			JDBCUtils.close(con, ps);
		}
	}
    
    public Map search(String infonation) throws SQLException {
		Map m = null;
		try {
			con = JDBCUtils.getConnection();
			String sql = "select * from map where infonation=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, infonation);
			rs = ps.executeQuery();
			while (rs.next()) {
				
				String city = rs.getString(1);
				infonation = rs.getString(2);
				double latitude = rs.getDouble(3);
				double longitude = rs.getDouble(4);
				m = new Map(city, infonation, latitude, longitude);
			}
			return m;
		} finally {
			JDBCUtils.close(con, ps, rs);
	}
}
}
