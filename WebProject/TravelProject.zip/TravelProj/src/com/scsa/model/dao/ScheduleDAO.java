package com.scsa.model.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.samsung.biz.common.JDBCUtils;
import com.scsa.model.vo.Schedule;

import java.sql.Connection;
import java.util.ArrayList;
public class ScheduleDAO {
	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	public void addSchedule(Schedule s) throws SQLException {
		String sql = "insert into schedule values(sche_seq.nextval,?,?,?,?,?,?)";
			con = JDBCUtils.getConnection();
			ps = con.prepareStatement(sql);
			
			ps.setString(1, s.getSchedulestart());
			ps.setString(2, s.getScheduleend());
			ps.setString(3, s.getSchedulenation());
			ps.setString(4, s.getCity());
			ps.setString(5, s.getSchedulesite());
			ps.setString(6, s.getId());
			ps.executeUpdate();
			JDBCUtils.close(con, ps);
		}
	
	public void delete(String id) throws SQLException{
		String sql="delete from Schedule where id=?";
		try{
			con=JDBCUtils.getConnection();
			ps=con.prepareStatement(sql);
			ps.setString(1, id);
			ps.executeUpdate();
		}finally{
			JDBCUtils.close(con, ps);
		}
	}
	public void update(Schedule s) throws SQLException{
		String sql="update Schedule set schedulestart=?, scheduleend=?, schedulenation=?,"
				+ " city=?, schedulesite=? where id=?";
		
		try{
			con=JDBCUtils.getConnection();
			ps=con.prepareStatement(sql);
			ps.setString(1, s.getSchedulestart());
			ps.setString(2, s.getScheduleend());
			ps.setString(3, s.getSchedulenation());
			ps.setString(4, s.getCity());
			ps.setString(5, s.getSchedulesite());
			ps.setString(6, s.getId());
			ps.executeUpdate();
		}finally{
			JDBCUtils.close(con, ps);
		}
	}	
	public ArrayList<Schedule> search(String id) throws SQLException{
		String sql="select * from Schedule where id=? ";
		Schedule s=null;
		ArrayList<Schedule> list =  new ArrayList<Schedule>();
		try{
			con=JDBCUtils.getConnection();
			ps=con.prepareStatement(sql);
			ps.setString(1, id);
			rs=ps.executeQuery();
			while(rs.next()){
				int schedulenum = rs.getInt(1);
				String schedulestart = rs.getString(2);
				String scheduleend = rs.getString(3);
				String schedulenation = rs.getString(4);
				String city = rs.getString(5);
				String schedulesite = rs.getString(6);
				id= rs.getString(7);
				s=new Schedule(schedulenum, id, schedulestart, scheduleend, schedulenation, city, schedulesite) ;
				list.add(s);
			}
			return list;
		}finally{
			JDBCUtils.close(con, ps, rs);
		}
	}	
	
	public ArrayList<Schedule> searchAll() throws SQLException{
		String sql="select schedulenation, city, id from schedule order by id";
		Schedule s = null;
		ArrayList<Schedule> list =  new ArrayList<Schedule>();
		
		try{
			con=JDBCUtils.getConnection();
			ps=con.prepareStatement(sql);
			rs=ps.executeQuery();
			while(rs.next()){
				String schedulenation = rs.getString(1);
				String city = rs.getString(2);
				String id= rs.getString(3);
				s=new Schedule(schedulenation, city, id);
				list.add(s);
			}
			return list;
		}finally{
			JDBCUtils.close(con, ps, rs);
		}
	}	
	}
