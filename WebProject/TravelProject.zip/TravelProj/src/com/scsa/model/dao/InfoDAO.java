package com.scsa.model.dao;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import oracle.jdbc.driver.OracleResultSet;
import oracle.sql.CLOB;

import com.samsung.biz.common.JDBCUtils;
import com.scsa.model.vo.Info;
/**
 * 여행정보를 데이터베이스 입력, 조회, 삭제, 수정 
 */
public class InfoDAO {
	Connection con = null;
	PreparedStatement st = null;
	ResultSet rs = null;
	
	public void addInfo(Info i) throws SQLException, IOException {
		String strQuery = "INSERT INTO INFO VALUES( ?, ?, ?, EMPTY_CLOB() )";
		con.setAutoCommit(false);
    	
		st = con.prepareStatement(strQuery);
		st.setInt(1, i.getInfonum());
		st.setString(2, i.getInfonation() );
		st.setString(3, i.getInfoimage());
		
		// Insert Row
		int nRowCnt = st.executeUpdate();
		st.close();
		if (nRowCnt == 1) {
			// Make Select Query & Row Lock
			strQuery = "SELECT INFODESC FROM INFO WHERE INFONUM = ? FOR UPDATE";
			st = con.prepareStatement(strQuery);
			st.setInt(1, i.getInfonum());
			ResultSet rs = st.executeQuery();

			if (rs.next()) {
				CLOB clob = ((OracleResultSet) rs).getCLOB("INFODESC");
//				DelegatingResultSet dRS = (DelegatingResultSet) rs;				
//				OracleResultSet oRS = (OracleResultSet) dRS.getInnermostDelegate();
//				CLOB clob = ((OracleResultSet) oRS).getCLOB("INFODESC");
				
				BufferedWriter buffW = new BufferedWriter(
						clob.getCharacterOutputStream());
				buffW.write(i.getInfodesc());
				rs.close();
				buffW.close();
			}
			// Commit
			con.commit();
			con.setAutoCommit(true);
			st.close();
			con.close();
		}
    }
    
    public void delete(String infonation) throws SQLException {
    	String sql = "delete from info where infonation=?";
		try {
			con = JDBCUtils.getConnection();
			st = con.prepareStatement(sql);
			st.setString(1, infonation);
			st.executeUpdate();
		} finally {
			JDBCUtils.close(con, st);
		}
	}

	public Info search(String infonation) throws SQLException, IOException {
		String sql = "select * from info where infonation=?";
		Info i = null;
		
		try {
			con = JDBCUtils.getConnection();
			st = con.prepareStatement(sql);
			st.setString(1, infonation);
			st.executeQuery();
			rs = st.getResultSet();
			
			if(rs.next()){
				int infonum = rs.getInt(1);
				infonation = rs.getString(2);
				String infoimage = rs.getString(3);
				Reader conReader = rs.getCharacterStream(4);
				
				StringBuilder sb = new StringBuilder();
				char[] cb = new char[1000];
				
				int readCnt = 0;
				
				while((readCnt=conReader.read(cb,0,1024))!=-1){
					sb.append(cb, 0, readCnt);
					sb.append("<br>");
					
					i = new Info(infonum, infonation, infoimage, sb.toString());
				}
				conReader.close();
			}
			return i;
		} finally {
			JDBCUtils.close(con, st, rs);
		}
	}
}
