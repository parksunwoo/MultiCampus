package com.scsa.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.scsa.model.dao.MapDAO;
import com.scsa.model.dao.ScheduleDAO;


public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		request.setCharacterEncoding("utf-8");
		String action=request.getParameter("action");
		CommandHandler handler = null;
			
		switch (action) {
		case "addSchedule":
			handler=new addScheduleHandler();
			break;
		case "listSchedule":
				handler=new listScheduleHandler();
				break;
		case "infoMain":
			response.sendRedirect("sitepage.jsp?content=infoMain.jsp");
			return;
		case "registerInfo":
			String dir = "images";
			String saveFullDir = getServletContext().getRealPath(dir);
			request.setAttribute("saveFullDir", saveFullDir);
			handler=new RegisterInfoHandler();
			break;
		case "viewInfo":
			handler=new viewInfoHandler();
			break;
			
		case "viewMap":
			handler=new viewMapHandler();
			break;
		case "travelBoard":
			request.setAttribute("flag", "asd");
			response.sendRedirect("sitepage.jsp?content=getBoardList.jsp");
			return;
		case "Magazine":
			response.sendRedirect("sitepage.jsp?content=magazine.jsp");
			return;
		case "index":
			response.sendRedirect("sitepage.jsp?content=index.jsp");
			return;
		}
		String viewPage=handler.process(request, response);
		RequestDispatcher dis = getServletContext().getRequestDispatcher(viewPage);
		dis.forward(request, response);
	}
}
