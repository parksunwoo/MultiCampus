package com.scsa.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.scsa.model.dao.InfoDAO;
import com.scsa.model.vo.Info;
public class viewInfoHandler implements CommandHandler {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) {
		String infonation=request.getParameter("infonation").trim();
		InfoDAO idao=new InfoDAO();
		try {
			Info i=idao.search(infonation);
			request.setAttribute("info", i);
			return "/sitepage.jsp?content=infoIndex.jsp";
		} catch (SQLException e) {
			String msg=e.getMessage();
			request.setAttribute("msg", msg);
			request.setAttribute("content", "/error.jsp");
		} catch (IOException e) {
			String msg=e.getMessage();
			request.setAttribute("msg", msg);
			request.setAttribute("content", "/error.jsp");
		}
		return "/sitepage.jsp";
	}

}
