package com.scsa.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.scsa.model.dao.MapDAO;
import com.scsa.model.vo.Map;
public class viewMapHandler implements CommandHandler {
	
	@Override
	public String process(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String infonation=request.getParameter("infonation").trim();
		MapDAO  mdao=new MapDAO();
		try {
			Map m=mdao.search(infonation);
			request.setAttribute("map", m);
			return "/sitepage.jsp?content=infoMap.jsp";
		} catch (SQLException e) {
			String msg= e.getMessage();
			request.setAttribute("msg", msg);
			request.setAttribute("content", "/error.jsp");
		}
		return "/sitepage.jsp";
	}
}
