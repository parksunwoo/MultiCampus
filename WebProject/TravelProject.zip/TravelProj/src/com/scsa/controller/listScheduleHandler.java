package com.scsa.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.scsa.model.dao.ScheduleDAO;
import com.scsa.model.vo.Schedule;
/**
 * 로그인시 입력한 여행계획정보를 조회할 수 있습니다.
 */
public class listScheduleHandler implements CommandHandler {
	ScheduleDAO sdao=new ScheduleDAO();
	
	@Override
	public String process(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(); //  
		String userid = (String) session.getAttribute("user");
		
		ArrayList<Schedule> list;
		try {
			list = sdao.search(userid);
			
			request.setAttribute("listSchedule", list);
			request.setAttribute("content", "/calendar.jsp");
			return "/sitepage.jsp?content=calendar.jsp";

		} catch (SQLException e) {
			String msg="달력목록을 불러오는 중 문제발생(L)";
			request.setAttribute("msg", msg);
			request.setAttribute("content", "/error.jsp");
		}
		return "/sitepage.jsp?content=calendar.jsp";
		
	}
}
