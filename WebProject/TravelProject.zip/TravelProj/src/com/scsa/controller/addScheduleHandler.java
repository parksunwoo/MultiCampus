package com.scsa.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.scsa.model.dao.ScheduleDAO;
import com.scsa.model.vo.Schedule;

/**
 * Main Diary를 클릭시 달력에 여행일정 정보를 입력할 수 있습니다.
 */

public class addScheduleHandler implements CommandHandler {

	@Override
	public String process(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		try {
			new ScheduleDAO().addSchedule(new Schedule(
					request.getParameter("id"),
					request.getParameter("schedulestart"),
					request.getParameter("scheduleend"),
					request.getParameter("schedulenation"),
					request.getParameter("city"),
					request.getParameter("schedulesite") ));
					request.setAttribute("content", "/calendar.jsp");
					return "/sitepage.jsp?";

		} catch (NumberFormatException e) {
			String msg="여행일정 추가 중 문제발생(R)";
			request.setAttribute("msg", msg);
			request.setAttribute("content", "/error.jsp");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//return "/sitepage.jsp?content=main.do?action=listSchedule";
		return "/sitepage.jsp";
	}
}
