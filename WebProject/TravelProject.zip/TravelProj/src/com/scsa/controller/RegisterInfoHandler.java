package com.scsa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.scsa.model.dao.InfoDAO;
import com.scsa.model.vo.Info;
public class RegisterInfoHandler implements CommandHandler {

	@Override
	public String process(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");

		String saveFullDir = (String) request.getAttribute("saveFullDir");
		int maxFileSize = 5 * 1024 * 1024;
		String encoding = "utf-8";

		MultipartRequest mulRequest = new MultipartRequest(request, saveFullDir, maxFileSize, encoding);
		
		String infonum = mulRequest.getParameter("infonum").trim();
		String infonation = mulRequest.getParameter("infonation").trim();
		String infodesc = mulRequest.getParameter("infodesc").trim();
		String infoimage = mulRequest.getFilesystemName("infoimage");
		String infoimage1 = mulRequest.getParameter("infoimage");
		
		Info info = new Info(Integer.parseInt(infonum), infonation, infoimage, infodesc);   
		
		InfoDAO idao=new InfoDAO();
			try {
				idao.addInfo(info);
				request.setAttribute("info", info);
				request.setAttribute("content", "/infoIndex.jsp");
			} catch (SQLException e) {
				String msg="info(R)";
				request.setAttribute("msg", msg);
				request.setAttribute("content", "/error.jsp");
			}
		return "/sitepage.jsp?content=infoMain.jsp";
	}

}
