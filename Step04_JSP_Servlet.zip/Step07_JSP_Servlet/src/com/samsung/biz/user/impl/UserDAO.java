package com.samsung.biz.user.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.samsung.biz.user.vo.UserVO;
import com.samsung.biz.utils.JDBCUtil;

public class UserDAO {
	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	
	public void addUser(UserVO vo){
	}
	
	public UserVO login(UserVO vo){
		conn = JDBCUtil.getConnections();
		UserVO user = null;
		String sql = "select * from users where id=? and password=?";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, vo.getId());
			stmt.setString(2, vo.getPassword());
			rs = stmt.executeQuery();
			
			if(rs.next()){
				user = new UserVO();
				
				user.setId(rs.getString("id"));
				user.setPassword(rs.getString("password"));
				user.setName(rs.getString("name") );
				user.setRole(rs.getString("role") );
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		JDBCUtil.close(conn, stmt, rs);
		return user;
	}
}
