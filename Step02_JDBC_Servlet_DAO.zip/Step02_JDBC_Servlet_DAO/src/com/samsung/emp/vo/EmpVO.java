package com.samsung.emp.vo;

import java.util.Date;

public class EmpVO {
	private int EMPLOYEE_ID;
	private String FIRST_NAME;
	private String EMAIL;
	private Date HIRE_DATE;
	private int salary;
	private int DEPARTMENT_ID;
	
	public int getEMPLOYEE_ID() {
		return EMPLOYEE_ID;
	}
	public void setEMPLOYEE_ID(int eMPLOYEE_ID) {
		EMPLOYEE_ID = eMPLOYEE_ID;
	}
	public String getFIRST_NAME() {
		return FIRST_NAME;
	}
	public void setFIRST_NAME(String fIRST_NAME) {
		FIRST_NAME = fIRST_NAME;
	}
	public String getEMAIL() {
		return EMAIL;
	}
	public void setEMAIL(String eMAIL) {
		EMAIL = eMAIL;
	}
	public Date getHIRE_DATE() {
		return HIRE_DATE;
	}
	public void setHIRE_DATE(Date hIRE_DATE) {
		HIRE_DATE = hIRE_DATE;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getDEPARTMENT_ID() {
		return DEPARTMENT_ID;
	}
	public void setDEPARTMENT_ID(int dEPARTMENT_ID) {
		DEPARTMENT_ID = dEPARTMENT_ID;
	}
	public EmpVO(int eMPLOYEE_ID, String fIRST_NAME, String eMAIL,
			Date hIRE_DATE, int salary, int dEPARTMENT_ID) {
		super();
		EMPLOYEE_ID = eMPLOYEE_ID;
		FIRST_NAME = fIRST_NAME;
		EMAIL = eMAIL;
		HIRE_DATE = hIRE_DATE;
		this.salary = salary;
		DEPARTMENT_ID = dEPARTMENT_ID;
	}
	public EmpVO() {
		super();
	}
	@Override
	public String toString() {
		return "EmpVO [EMPLOYEE_ID=" + EMPLOYEE_ID + ", FIRST_NAME="
				+ FIRST_NAME + ", EMAIL=" + EMAIL + ", HIRE_DATE=" + HIRE_DATE
				+ ", salary=" + salary + ", DEPARTMENT_ID=" + DEPARTMENT_ID
				+ "]";
	}
	
}
