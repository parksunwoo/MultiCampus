package com.samsung.emp.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import com.samsung.emp.vo.EmpVO;
import com.samsung.utils.JDBCUtils;

public class EmpDAO {
	private Connection conn =null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	
	/*public void addEmp(EmpVO vo){
		try {
			conn = JDBCUtils.getConnections();
			String sql = "insert into employees(EMPLOYEE_ID, FIRST_NAME, EMAIL, HIRE_DATE, salary, DEPARTMENT_ID) " + 
					"values((select nvl(max(seq), 0) from employees) + 1, ?, ?, sysdate, ?, 'guest')";
			stmt = conn.prepareStatement(sql);
			
			stmt.setString(1, vo.getFIRST_NAME());
			stmt.setString(2, vo.getEMAIL());
			stmt.setInt(3, vo.getSalary());
			stmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, stmt, rs);
		}
	}
	public void updateEmp(EmpVO e){}
	public void deleteEmp(EmpVO e){}*/
	
	public EmpVO getEmp(EmpVO e){
		EmpVO emp = null;
		
		try {
			conn = JDBCUtils.getConnections();
			String sql = "select * from employees where EMPLOYEE_ID=?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, e.getEMPLOYEE_ID());
			rs = stmt.executeQuery();
			if(rs.next()){
				emp = new EmpVO(rs.getInt("EMPLOYEE_ID"),rs.getString("fIRST_NAME"), rs.getString("EMAIL"), rs.getDate("hIRE_DATE"), rs.getInt("salary"), rs.getInt("dEPARTMENT_ID"));
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally{
			JDBCUtils.close(conn, stmt, rs);
		}
		return emp;
		}
	
	public ArrayList<EmpVO> getEmpList(){
		EmpVO emp = null;
		ArrayList<EmpVO> list = new ArrayList<EmpVO>();
		
		try {
			conn = JDBCUtils.getConnections();
			String sql = "select * from employees";
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			while(rs.next()){
				emp = new EmpVO(rs.getInt("EMPLOYEE_ID"),rs.getString("fIRST_NAME"), rs.getString("EMAIL"), rs.getDate("hIRE_DATE"), rs.getInt("salary"), rs.getInt("dEPARTMENT_ID"));
				list.add(emp);
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally{
			JDBCUtils.close(conn, stmt, rs);
		}
		return list;
		}
	
	
}
