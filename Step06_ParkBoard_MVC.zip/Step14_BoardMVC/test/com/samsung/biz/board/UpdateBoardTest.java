package com.samsung.biz.board;

import com.samsung.biz.user.board.impl.BoardDAO;
import com.samsung.biz.user.board.vo.BoardVO;

public class UpdateBoardTest {
	public static void main(String[] args) {
		BoardVO vo = new BoardVO();
		vo.setTitle("New Title");
		vo.setContent("New Content");
		vo.setSeq(21);
		
		BoardDAO dao = new BoardDAO();
		dao.updateBoard(vo);
	}
}
