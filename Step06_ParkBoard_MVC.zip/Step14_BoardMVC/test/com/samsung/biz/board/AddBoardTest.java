package com.samsung.biz.board;

import com.samsung.biz.user.board.impl.BoardDAO;
import com.samsung.biz.user.board.vo.BoardVO;

public class AddBoardTest {
	public static void main(String[] args) {
		BoardDAO dao = new BoardDAO();
		BoardVO vo = new BoardVO();
		vo.setTitle("�׽�Ʈ1");
		vo.setNickname("�׽�Ʈ 1");
		vo.setContent("�׽�Ʈ 1");
		vo.setUserid("�׽�Ʈ 1");
		
		dao.addBoard(vo);
	
		
		
		
		
	}
}
