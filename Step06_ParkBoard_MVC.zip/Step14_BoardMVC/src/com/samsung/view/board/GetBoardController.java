package com.samsung.view.board;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.biz.user.board.impl.BoardDAO;
import com.samsung.biz.user.board.vo.BoardVO;
import com.samsung.view.controller.Controller;

public class GetBoardController implements Controller{

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession();
		String id =(String)session.getAttribute("id");
		if(id == null){
			return "login.jsp";
		}
		
		int seq = Integer.parseInt(request.getParameter("seq"));
		BoardVO vo = new BoardVO();
		vo.setSeq(seq);
		
		BoardDAO dao = new BoardDAO();
		BoardVO board = dao.getBoard(vo);
		request.setAttribute("board", board);
		return "getBoard.jsp";
	}
}
