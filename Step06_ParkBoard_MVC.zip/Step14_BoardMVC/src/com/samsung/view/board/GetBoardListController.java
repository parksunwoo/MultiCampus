package com.samsung.view.board;

import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.biz.user.board.impl.BoardDAO;
import com.samsung.biz.user.board.vo.BoardVO;
import com.samsung.view.controller.Controller;

public class GetBoardListController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession sess = request.getSession();
		String id = (String) sess.getAttribute("id");
		if(id == null){
			return "login.jsp";
		}
		
		String searchCondition = "";
		if(request.getParameter("searchCondition") ==null){
			searchCondition = "TITLE";
		}else{
			searchCondition = request.getParameter("searchCondition");
		}
		
		String searchKeyword = "";
		if(request.getParameter("searchKeyword") !=null){
			searchKeyword = request.getParameter("searchKeyword");
		}else{
			searchKeyword = "";
		}
		
		BoardVO vo = new BoardVO();
		vo.setSearchCondition(searchCondition);
		vo.setSearchKeyword(searchKeyword);
		
		BoardDAO dao = new BoardDAO();
		ArrayList<BoardVO> list = dao.getBoardList(vo);
		request.setAttribute("list", list);
		
		return "getBoardList.jsp";
	}

}
