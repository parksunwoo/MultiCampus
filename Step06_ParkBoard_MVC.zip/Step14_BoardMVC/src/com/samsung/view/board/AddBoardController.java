package com.samsung.view.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.biz.user.board.impl.BoardDAO;
import com.samsung.biz.user.board.vo.BoardVO;
import com.samsung.view.controller.Controller;

public class AddBoardController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession();
		String id =(String)session.getAttribute("id");
		if(id == null){
			return  "login.jsp";
		}
		
		String title = request.getParameter("title");
		String nickname = request.getParameter("nickname");
		String content = request.getParameter("content");
		
		BoardVO vo = new BoardVO();
		vo.setTitle(title);
		vo.setNickname(nickname);
		vo.setContent(content);
		BoardDAO dao = new BoardDAO();
		dao.addBoard(vo);
		 
		return "getBoardList.do" ;
	}
}
